from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from ..settings import SET
from ..db import list_pending, get_user_by_tgid, update_user
from ..utils import plan_apply
from datetime import datetime

router = Router()

@router.callback_query(F.data == "admin:menu")
async def admin_menu(c: CallbackQuery):
    if c.from_user.id not in SET.admin_ids:
        await c.message.answer("Доступ запрещён.")
        return
    await c.message.answer("Админ‑панель:\n• /pending — заявки\n• /grant_trial <tg_id>\n• /grant_paid <tg_id>\n• /grant_unlim <tg_id>")

@router.message(F.text.startswith("/pending"))
async def admin_pending(m: Message):
    if m.from_user.id not in SET.admin_ids:
        return
    pend = list_pending()
    if not pend:
        await m.answer("Нет заявок.")
        return
    lines = ["Заявки:"]
    for u in pend:
        lines.append(f"• tg_id={u.tg_id} @{u.username}")
    await m.answer("\n".join(lines))

@router.message(F.text.startswith("/grant_trial"))
async def grant_trial(m: Message):
    if m.from_user.id not in SET.admin_ids:
        return
    parts = m.text.split()
    if len(parts) < 2:
        await m.answer("Формат: /grant_trial <tg_id>")
        return
    tg_id = int(parts[1])
    u = get_user_by_tgid(tg_id)
    if not u:
        await m.answer("Пользователь не найден")
        return
    expires_at, limit = plan_apply("trial", datetime.utcnow())
    u = update_user(u, status="approved", plan="trial", devices_limit=limit, expires_at=expires_at)
    await m.answer(f"OK. Выдан trial (до unix {expires_at}).")

@router.message(F.text.startswith("/grant_paid"))
async def grant_paid(m: Message):
    if m.from_user.id not in SET.admin_ids:
        return
    parts = m.text.split()
    if len(parts) < 2:
        await m.answer("Формат: /grant_paid <tg_id>")
        return
    tg_id = int(parts[1])
    u = get_user_by_tgid(tg_id)
    if not u:
        await m.answer("Пользователь не найден")
        return
    expires_at, limit = plan_apply("paid", datetime.utcnow())
    u = update_user(u, status="approved", plan="paid", devices_limit=limit, expires_at=expires_at)
    await m.answer("OK. Выдан paid.")

@router.message(F.text.startswith("/grant_unlim"))
async def grant_unlim(m: Message):
    if m.from_user.id not in SET.admin_ids:
        return
    parts = m.text.split()
    if len(parts) < 2:
        await m.answer("Формат: /grant_unlim <tg_id>")
        return
    tg_id = int(parts[1])
    u = get_user_by_tgid(tg_id)
    if not u:
        await m.answer("Пользователь не найден")
        return
    expires_at, limit = plan_apply("unlimited", datetime.utcnow())
    u = update_user(u, status="approved", plan="unlimited", devices_limit=limit, expires_at=expires_at)
    await m.answer("OK. Выдан unlimited.")
