from aiogram import Router, F
from aiogram.types import CallbackQuery, BufferedInputFile
from ..db import get_user_by_tgid, count_user_peers, add_peer_row, get_user_peers, update_user
from ..settings import SET
from ..keyboards import kb_user_main
from ..utils import check_limit, human_dt, make_qr_png
from ..wgd_api import wgd, WGDError
from datetime import datetime

router = Router()

@router.callback_query(F.data == "user:plan")
async def user_plan(c: CallbackQuery):
    u = get_user_by_tgid(c.from_user.id)
    if not u or u.status != "approved":
        await c.message.answer("Недоступно. Дождитесь одобрения администратора.")
        return
    exp = human_dt(u.expires_at) if u.expires_at else "∞"
    limit = "безлимит" if u.devices_limit < 0 else str(u.devices_limit)
    await c.message.answer(
        f"Ваш план: {u.plan}\nЛимит устройств: {limit}\nДействует до: {exp}"
    )

@router.callback_query(F.data == "user:peers")
async def user_peers(c: CallbackQuery):
    u = get_user_by_tgid(c.from_user.id)
    if not u or u.status != "approved":
        await c.message.answer("Недоступно. Дождитесь одобрения администратора.")
        return
    peers = get_user_peers(u.id)
    if not peers:
        await c.message.answer("У вас нет активных подключений.")
        return
    lines = ["Ваши подключения:"]
    for p in peers:
        lines.append(f"• {p.name} (id={p.wgd_peer_id})")
    await c.message.answer("\n".join(lines))

@router.callback_query(F.data == "user:newpeer")
async def user_newpeer(c: CallbackQuery):
    u = get_user_by_tgid(c.from_user.id)
    if not u or u.status != "approved":
        await c.message.answer("Недоступно. Дождитесь одобрения администратора.")
        return
    now = int(datetime.utcnow().timestamp())
    if u.plan != "unlimited" and (not u.expires_at or now > u.expires_at):
        await c.message.answer("Срок действия вашего тарифа истёк. Обратитесь к администратору.")
        return

    cur = count_user_peers(u.id)
    if not check_limit(cur, u.devices_limit):
        await c.message.answer("Достигнут лимит устройств для вашего тарифа.")
        return

    name = f"{c.from_user.username or 'user'}-{c.from_user.id}-{now}"
    try:
        peer_id = await wgd.create_peer(SET.wgd_interface, name)
        config_text = await wgd.get_peer_config(peer_id)
    except WGDError as e:
        await c.message.answer(f"Ошибка создания подключения: {e}")
        return

    p = add_peer_row(u.id, SET.wgd_interface, peer_id, name)

    cfg_bytes = config_text.encode("utf-8")
    qr_bytes = make_qr_png(config_text)

    await c.message.answer("Подключение создано. Скачайте конфигурацию или отсканируйте QR‑код.")
    await c.message.answer_document(BufferedInputFile(cfg_bytes, filename=f"{name}.conf"))
    await c.message.answer_photo(BufferedInputFile(qr_bytes, filename=f"{name}.png"))

@router.callback_query(F.data == "user:delpeer")
async def user_delpeer(c: CallbackQuery):
    u = get_user_by_tgid(c.from_user.id)
    if not u or u.status != "approved":
        await c.message.answer("Недоступно.")
        return
    peers = get_user_peers(u.id)
    if not peers:
        await c.message.answer("У вас нет активных подключений.")
        return
    target = sorted(peers, key=lambda x: x.created_at)[-1]
    try:
        await wgd.delete_peer(target.wgd_peer_id)
    except Exception as e:
        await c.message.answer(f"Ошибка удаления в WGDashboard: {e}")
        return
    from ..db import revoke_peer_row
    revoke_peer_row(target.id)
    await c.message.answer(f"Подключение {target.name} удалено.")
