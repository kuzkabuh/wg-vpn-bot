from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart
from ..db import get_or_create_user, get_user_by_tgid
from ..settings import SET
from ..keyboards import kb_register, kb_user_main

router = Router()

@router.message(CommandStart())
async def cmd_start(m: Message):
    u = get_or_create_user(m.from_user.id, m.from_user.username, m.from_user.first_name, m.from_user.last_name)
    if u.status == "pending":
        await m.answer(
            "Привет! 👋\n\nВы ещё не одобрены. Нажмите \"Регистрация\", чтобы отправить заявку администратору.",
            reply_markup=kb_register()
        )
        return

    is_admin = m.from_user.id in SET.admin_ids
    await m.answer("Главное меню:", reply_markup=kb_user_main(is_admin=is_admin))

@router.callback_query(F.data == "reg:start")
async def reg_start(c: CallbackQuery):
    u = get_user_by_tgid(c.from_user.id)
    if not u:
        await c.message.answer("Ошибка: пользователь не найден. Повторите /start")
        return
    if u.status != "pending":
        await c.message.answer("Заявка уже обработана. Нажмите /start")
        return

    text = (
        f"🆕 Заявка на доступ\n"
        f"tg_id={c.from_user.id}\n"
        f"username=@{c.from_user.username}"
    )
    for aid in SET.admin_ids:
        try:
            await c.bot.send_message(aid, text)
            await c.bot.send_message(aid, "Откройте Админ‑панель → Заявки")
        except Exception:
            pass

    await c.message.answer("Заявка отправлена. Ожидайте решения администратора.")
    await c.answer()
