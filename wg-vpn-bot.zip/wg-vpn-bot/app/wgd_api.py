"""
Адаптер WGDashboard API v4.3.0.1

Примечание: у разных сборок WGDashboard пути могут отличаться.
Здесь сделана конфигурируемая прослойка с явным перечислением endpoint'ов.
Если ваш WGDashboard использует другие пути — поправьте в EndpointMap.
"""
from __future__ import annotations
import httpx
from typing import Dict, Any
from .settings import SET

class WGDError(Exception):
    pass

class EndpointMap:
    # При необходимости подстройте пути ниже под вашу сборку WGDashboard
    create_peer = "/api/v4/peers"          # POST { interface, name } -> {id}
    delete_peer = "/api/v4/peers/{peer_id}" # DELETE
    get_config  = "/api/v4/peers/{peer_id}/config"  # GET -> text/plain
    stats_peer  = "/api/v4/peers/{peer_id}" # GET -> json

class WGDClient:
    def __init__(self, base: str, token: str, timeout: float = 10.0):
        self.base = base.rstrip('/')
        self.token = token
        self.timeout = timeout
        self.headers = {"Authorization": f"Bearer {token}"}

    async def create_peer(self, interface: str, name: str) -> str:
        url = self.base + EndpointMap.create_peer
        payload = {"interface": interface, "name": name}
        async with httpx.AsyncClient(timeout=self.timeout) as cli:
            r = await cli.post(url, headers=self.headers, json=payload)
            if r.status_code >= 300:
                raise WGDError(f"Create peer failed: {r.status_code} {r.text}")
            data = r.json()
            peer_id = str(data.get("id") or data.get("peer_id"))
            if not peer_id:
                raise WGDError(f"Unexpected create response: {data}")
            return peer_id

    async def delete_peer(self, peer_id: str):
        url = self.base + EndpointMap.delete_peer.format(peer_id=peer_id)
        async with httpx.AsyncClient(timeout=self.timeout) as cli:
            r = await cli.delete(url, headers=self.headers)
            if r.status_code >= 300:
                raise WGDError(f"Delete peer failed: {r.status_code} {r.text}")
            return True

    async def get_peer_config(self, peer_id: str) -> str:
        url = self.base + EndpointMap.get_config.format(peer_id=peer_id)
        async with httpx.AsyncClient(timeout=self.timeout) as cli:
            r = await cli.get(url, headers=self.headers)
            if r.status_code >= 300:
                raise WGDError(f"Get config failed: {r.status_code} {r.text}")
            return r.text

    async def get_peer_stats(self, peer_id: str) -> Dict[str, Any]:
        url = self.base + EndpointMap.stats_peer.format(peer_id=peer_id)
        async with httpx.AsyncClient(timeout=self.timeout) as cli:
            r = await cli.get(url, headers=self.headers)
            if r.status_code >= 300:
                raise WGDError(f"Stats peer failed: {r.status_code} {r.text}")
            return r.json()

wgd = WGDClient(SET.wgd_api_base, SET.wgd_api_token)
