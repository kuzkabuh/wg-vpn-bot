from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardMarkup

def kb_register() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="Регистрация", callback_data="reg:start")
    return b.as_markup()

def kb_user_main(is_admin: bool=False) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="Мой тариф", callback_data="user:plan")
    b.button(text="Мои подключения", callback_data="user:peers")
    b.button(text="Создать подключение", callback_data="user:newpeer")
    b.button(text="Удалить подключение", callback_data="user:delpeer")
    if is_admin:
        b.button(text="Админ‑панель", callback_data="admin:menu")
    b.adjust(1)
    return b.as_markup()
