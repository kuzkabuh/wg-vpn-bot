import io
import qrcode
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from .settings import SET

PLAN_DEFAULTS = {
    "trial": {
        "days": SET.trial_days,
        "limit": SET.trial_device_limit,
    },
    "paid": {
        "days": SET.paid_days,
        "limit": SET.paid_device_limit,
    },
    "unlimited": {
        "days": 36500,   # фактически бессрочно
        "limit": -1,
    }
}

def make_qr_png(data: str) -> bytes:
    qr = qrcode.QRCode(box_size=8, border=2)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    bio = io.BytesIO()
    img.save(bio, format="PNG")
    return bio.getvalue()

def human_dt(ts: int) -> str:
    return datetime.fromtimestamp(ts).strftime("%d.%m.%Y %H:%M")

def plan_apply(plan: str, from_dt: datetime | None = None):
    from_dt = from_dt or datetime.utcnow()
    spec = PLAN_DEFAULTS.get(plan)
    if not spec:
        raise ValueError("unknown plan")
    end = from_dt + timedelta(days=spec["days"]) if spec["days"] < 36500 else from_dt + relativedelta(years=100)
    return int(end.timestamp()), spec["limit"]

def check_limit(current: int, limit: int) -> bool:
    if limit < 0:
        return True
    return current < limit
