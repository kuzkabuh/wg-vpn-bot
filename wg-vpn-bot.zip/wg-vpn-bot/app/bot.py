import logging
from aiogram import Dispatcher, BaseMiddleware
from aiogram.types import TelegramObject
from time import time
from .settings import SET
from .webhook import app, bot, dp  # FastAPI app, Bot, Dispatcher

# Подключаем роутеры
from .handlers.start import router as start_router
from .handlers.user import router as user_router
from .handlers.admin import router as admin_router

class RateLimitMiddleware(BaseMiddleware):
    def __init__(self, per_min: int):
        super().__init__()
        self.per_min = per_min
        self.users = {}

    async def __call__(self, handler, event: TelegramObject, data):
        uid = None
        if hasattr(event, 'from_user') and event.from_user:
            uid = event.from_user.id
        if uid:
            now = time()
            bucket = self.users.setdefault(uid, [])
            bucket[:] = [t for t in bucket if now - t < 60]
            if len(bucket) >= self.per_min:
                return
            bucket.append(now)
        return await handler(event, data)

# Настройка логирования
logging.basicConfig(level=getattr(logging, SET.log_level.upper(), logging.INFO))

# Регистрируем роутеры и миддлы только один раз
if not getattr(dp, '_initialized', False):
    dp.include_router(start_router)
    dp.include_router(user_router)
    dp.include_router(admin_router)
    dp.message.middleware(RateLimitMiddleware(SET.rate_limit_per_min))
    dp.callback_query.middleware(RateLimitMiddleware(SET.rate_limit_per_min))
    dp._initialized = True

# Утилита для установки вебхука (выполните вручную один раз)
async def set_webhook():
    url = f"{SET.webhook_base}/bot/{SET.webhook_secret}"
    await bot.set_webhook(url)

if __name__ == "__main__":
    # Локальный запуск (polling) — для отладки:
    import asyncio
    async def main():
        print("[DEV] Start polling...")
        await dp.start_polling(bot)
    asyncio.run(main())
