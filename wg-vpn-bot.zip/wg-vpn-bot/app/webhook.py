""" FastAPI веб‑приложение для Telegram вебхука (и доп. тех‑эндпоинтов). """
from fastapi import FastAPI, Request, HTTPException
from aiogram import Bot, Dispatcher
from aiogram.types import Update
from .settings import SET

app = FastAPI()

bot = Bot(token=SET.bot_token, parse_mode="HTML")
dp = Dispatcher()

# Хендлеры подключаются в app.bot (импортом), чтобы не дублировать

@app.post(f"/tg/{{secret}}")
async def telegram_webhook(secret: str, request: Request):
    if secret != SET.webhook_secret:
        raise HTTPException(status_code=403, detail="forbidden")
    body = await request.json()
    update = Update.model_validate(body)
    await dp.feed_update(bot, update)
    return {"ok": True}

@app.get("/health")
async def health():
    return {"status": "ok"}
